# 🚀 CÓMO USAR (Rápido)

## ✅ Lo que hace este script:

1. **Se ejecuta en tu PC** (usa los recursos de tu computadora)
2. **Descarga los PDFs** desde el servidor Termux
3. **Genera las portadas** en tu PC (página 1 de cada PDF)
4. **Sube las portadas** de vuelta al servidor
5. **Se limpia solo** (borra archivos temporales)

---

## 📦 Pasos:

### 1. Instalar Python (si no lo tienes)
https://www.python.org/downloads/

### 2. Instalar ImageMagick (recomendado)
https://imagemagick.org/script/download.php

**Windows**: Descargar el instalador `.exe`

### 3. Extraer el ZIP
Extraer `MangaPortadas-PC.tar.gz` en cualquier carpeta

### 4. Ejecutar

**Opción A - Doble click (Windows):**
```
Doble click en EJECUTAR.bat
```

**Opción B - Terminal:**
```bash
python generar_portadas.py
```

**Opción C - VS Code:**
```
Abrir generar_portadas.py
Presionar F5
```

---

## 🔧 Si el servidor está en otra IP:

**Windows CMD:**
```cmd
set SERVER_URL=http://TU_IP:3000
python generar_portadas.py
```

**Windows PowerShell:**
```powershell
$env:SERVER_URL="http://TU_IP:3000"
python generar_portadas.py
```

**Linux/Mac:**
```bash
export SERVER_URL=http://TU_IP:3000
python generar_portadas.py
```

---

## 📊 Ejemplo de salida:

```
═══════════════════════════════════════════════════════════
📚 GENERADOR DE PORTADAS - MANGA LIBRARY
═══════════════════════════════════════════════════════════

🔍 Detectando herramientas del sistema...
✅ Usando: ImageMagick

🔍 Conectando al servidor...
📡 URL: http://100.79.185.4:3000
✅ Conectado. Series encontradas: 6

📋 Series sin portada: 6

  [1/6] El Amor Es Una Ilusión Superstar
    ⬇️  Descargando PDF... ✓
    🎨 Generando portada (página 1)... ✓
    ⬆️  Subiendo al servidor... ✓
  ✓ Portada generada exitosamente

  [2/6] Firma de Amor
    ⬇️  Descargando PDF... ✓
    🎨 Generando portada (página 1)... ✓
    ⬆️  Subiendo al servidor... ✓
  ✓ Portada generada exitosamente

...

═══════════════════════════════════════════════════════════
✨ PROCESO COMPLETADO
═══════════════════════════════════════════════════════════
✅ Exitosas: 6
═══════════════════════════════════════════════════════════
```

---

## ❓ Problemas comunes:

### "No se encontró ninguna herramienta de conversión PDF"
→ Instala ImageMagick: https://imagemagick.org/script/download.php

### "No se pudo conectar al servidor"
→ Verifica que el servidor esté corriendo y que la IP sea correcta

### "PDF no encontrado"
→ El archivo fue eliminado o movido del servidor

---

## 💡 Ventajas de este método:

✅ **Usa tu PC**: Procesamiento rápido, no sobrecarga el servidor Termux  
✅ **Automático**: Procesa todas las series pendientes en un solo comando  
✅ **Seguro**: Descarga, procesa y sube, sin modificar archivos originales  
✅ **Sin cache**: Limpia todo al terminar, no deja rastros  

---

🎉 ¡Listo! Ahora tus mangas tendrán portadas automáticamente.
