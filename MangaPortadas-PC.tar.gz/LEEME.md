# 📚 Generador de Portadas - Manga Library

## 🚀 Inicio Rápido

### 1. Asegúrate de tener Python 3.6+ instalado

```bash
python --version
# o
python3 --version
```

### 2. Ejecutar desde VS Code

1. Abre VS Code
2. Abre esta carpeta (`PC-App`)
3. Abre el archivo `generar_portadas.py`
4. Presiona `F5` o click derecho → "Run Python File in Terminal"

### 3. Conectar a servidor remoto

**Windows (PowerShell):**
```powershell
$env:SERVER_URL="http://100.79.185.4:3000"
python generar_portadas.py
```

**Windows (CMD):**
```cmd
set SERVER_URL=http://100.79.185.4:3000
python generar_portadas.py
```

**Linux/Mac:**
```bash
SERVER_URL=http://100.79.185.4:3000 python3 generar_portadas.py
```

## ⚙️ Requisitos

### Python
- Python 3.6 o superior
- **No necesita librerías externas** - usa solo módulos estándar

### Herramienta de conversión PDF (al menos una)

**Windows:**
- [ImageMagick](https://imagemagick.org/script/download.php#windows) (recomendado)
- [Ghostscript](https://www.ghostscript.com/download/gsdnld.html)

**Linux:**
```bash
# Ubuntu/Debian
sudo apt install imagemagick

# O alternativas
sudo apt install mupdf-tools    # MuPDF
sudo apt install poppler-utils  # Poppler
```

**macOS:**
```bash
brew install imagemagick
```

## 📋 ¿Cómo funciona?

1. Se conecta al servidor de manga-library
2. Busca series que tengan portada tipo `pdf:volumeId:pageNumber`
3. Extrae la primera página del PDF como imagen JPEG
4. La sube al servidor automáticamente
5. Muestra progreso en pantalla
6. Limpia archivos temporales al terminar

## 🖥️ Ejemplo de salida

```
════════════════════════════════════════════════════════════
📚 GENERADOR DE PORTADAS - MANGA LIBRARY
════════════════════════════════════════════════════════════

🔍 Detectando herramientas del sistema...
✅ Usando: ImageMagick

🔍 Conectando al servidor...
📡 URL: http://192.168.1.100:3000
✅ Conectado. Series encontradas: 5
📋 Series sin portada: 2

  [1/2] Naruto... ✓
  [2/2] One Piece... ✓

════════════════════════════════════════════════════════════
✨ PROCESO COMPLETADO
════════════════════════════════════════════════════════════
✅ Exitosas: 2
════════════════════════════════════════════════════════════

Presiona Enter para salir...
```

## ⚠️ Importante

**La app debe ejecutarse en la misma máquina que el servidor** o tener acceso a los archivos PDF. Esto porque:

1. El servidor te dice dónde está el PDF: `/uploads/manga.pdf`
2. La app necesita leer ese archivo para extraer la página
3. Si el servidor está en otra máquina, los PDFs también están allá

### Soluciones:

**Opción 1:** Ejecutar en la misma máquina (Termux/Android)
```bash
cd /home/dev/manga-library-app/PC-App
python3 generar_portadas.py
```

**Opción 2:** Copiar carpeta a tu PC junto con los PDFs
```
PC-App/
└── generar_portadas.py
../uploads/
└── *.pdf  (copiar los PDFs aquí)
```

**Opción 3:** Montar carpeta remota via SSH/SFTP
```bash
# En tu PC, montar carpeta de Termux
sshfs dev@100.79.185.4:/home/dev/manga-library-app /mnt/manga
cd /mnt/manga/PC-App
python3 generar_portadas.py
```

## 🐛 Troubleshooting

### "No se encontró ninguna herramienta de conversión PDF"

Instala ImageMagick o alguna alternativa (ver sección Requisitos).

### "No se pudo conectar al servidor"

Verifica:
1. Que el servidor esté corriendo: `curl http://localhost:3000/api/series`
2. Que la IP/URL sea correcta
3. Que estés en la misma red (si es remoto)

### "PDF no encontrado"

La app busca los PDFs relativos a donde la ejecutas. Opciones:
1. Ejecutar desde `/home/dev/manga-library-app/PC-App/`
2. Copiar los PDFs a tu PC
3. Montar carpeta remota

### En Windows: "python no se reconoce"

Instala Python desde: https://www.python.org/downloads/

Al instalar, marca la opción "Add Python to PATH"

## 📝 Configuración

### Cambiar servidor
```bash
# Variable de entorno
export SERVER_URL=http://192.168.1.100:3000

# O editar en el código (línea 22)
SERVER_URL = 'http://192.168.1.100:3000'
```

### Cambiar calidad de imagen
```python
# Editar en el código (líneas 24-25)
QUALITY = 90  # 0-100 (90 es alta calidad)
DPI = 150     # Resolución (150 es buena)
```

## ✨ Ventajas

- ✅ Un solo archivo Python
- ✅ Sin dependencias externas (solo Python estándar)
- ✅ Funciona en Windows/Linux/Mac
- ✅ Interfaz limpia con colores
- ✅ Limpieza automática de archivos temporales
- ✅ Progreso en tiempo real
- ✅ Manejo de errores claro

---

**Para ejecutar rápido en VS Code:**
1. Abre `generar_portadas.py`
2. Presiona `F5`
3. ¡Listo!
