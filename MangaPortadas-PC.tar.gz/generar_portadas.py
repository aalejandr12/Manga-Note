#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════
📚 GENERADOR DE PORTADAS - MANGA LIBRARY
═══════════════════════════════════════════════════════════

App standalone para generar portadas desde PDFs
Sin dependencias externas - Solo Python 3.6+
"""

import os
import sys
import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urljoin
from http.client import HTTPException

# ═══════════════════════════════════════════════════════════
# CONFIGURACIÓN
# ═══════════════════════════════════════════════════════════

SERVER_URL = os.getenv('SERVER_URL', 'http://localhost:3000')
QUALITY = 90
DPI = 150

# ═══════════════════════════════════════════════════════════
# COLORES PARA TERMINAL
# ═══════════════════════════════════════════════════════════

class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[32m'
    BLUE = '\033[34m'
    YELLOW = '\033[33m'
    RED = '\033[31m'
    CYAN = '\033[36m'
    MAGENTA = '\033[35m'

def log(emoji, message, color=Colors.RESET):
    """Imprimir mensaje con color"""
    print(f"{color}{emoji} {message}{Colors.RESET}")

# ═══════════════════════════════════════════════════════════
# FUNCIONES HTTP
# ═══════════════════════════════════════════════════════════

def http_get(url):
    """GET request simple"""
    try:
        req = Request(url)
        with urlopen(req, timeout=30) as response:
            data = response.read().decode('utf-8')
            return json.loads(data)
    except Exception as e:
        raise Exception(f"Error HTTP GET: {e}")

def http_post_file(url, file_path):
    """POST multipart/form-data con archivo"""
    import random
    import string
    
    boundary = '----Boundary' + ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    
    with open(file_path, 'rb') as f:
        file_data = f.read()
    
    file_name = os.path.basename(file_path)
    
    # Construir body multipart
    body = (
        f'--{boundary}\r\n'
        f'Content-Disposition: form-data; name="image"; filename="{file_name}"\r\n'
        f'Content-Type: image/jpeg\r\n\r\n'
    ).encode('utf-8')
    body += file_data
    body += f'\r\n--{boundary}--\r\n'.encode('utf-8')
    
    # Hacer request
    req = Request(url, data=body, method='POST')
    req.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
    
    try:
        with urlopen(req, timeout=30) as response:
            data = response.read().decode('utf-8')
            return json.loads(data)
    except Exception as e:
        raise Exception(f"Error subiendo archivo: {e}")

# ═══════════════════════════════════════════════════════════
# DETECCIÓN DE HERRAMIENTAS
# ═══════════════════════════════════════════════════════════

def check_tool(tool_name):
    """Verificar si una herramienta está instalada"""
    try:
        subprocess.run([tool_name, '--version'], 
                      stdout=subprocess.DEVNULL, 
                      stderr=subprocess.DEVNULL,
                      check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def detect_pdf_tool():
    """Detectar qué herramienta PDF está disponible"""
    tools = {
        'convert': 'ImageMagick',
        'mutool': 'MuPDF',
        'pdftoppm': 'Poppler',
        'gs': 'Ghostscript'
    }
    
    for cmd, name in tools.items():
        if check_tool(cmd):
            return cmd, name
    
    return None, None

# ═══════════════════════════════════════════════════════════
# CONVERSIÓN PDF → IMAGEN
# ═══════════════════════════════════════════════════════════

def convert_pdf_to_image(pdf_path, output_path, page=1, tool='convert'):
    """Convertir página de PDF a imagen JPEG"""
    
    commands = {
        'convert': [
            'convert',
            '-density', str(DPI),
            f'{pdf_path}[{page-1}]',
            '-quality', str(QUALITY),
            '-flatten',
            output_path
        ],
        'mutool': [
            'mutool', 'draw',
            '-o', output_path,
            '-r', str(DPI),
            '-F', 'jpeg',
            pdf_path,
            str(page)
        ],
        'pdftoppm': [
            'pdftoppm',
            '-jpeg',
            '-f', str(page),
            '-l', str(page),
            '-r', str(DPI),
            pdf_path,
            output_path.replace('.jpg', '')
        ],
        'gs': [
            'gs',
            '-dNOPAUSE',
            '-dBATCH',
            '-sDEVICE=jpeg',
            f'-r{DPI}',
            f'-dJPEGQ={QUALITY}',
            f'-dFirstPage={page}',
            f'-dLastPage={page}',
            f'-sOutputFile={output_path}',
            pdf_path
        ]
    }
    
    cmd = commands.get(tool)
    if not cmd:
        raise Exception(f"Herramienta desconocida: {tool}")
    
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        
        # pdftoppm crea archivo con sufijo -1
        if tool == 'pdftoppm':
            temp_file = output_path.replace('.jpg', f'-{page}.jpg')
            if os.path.exists(temp_file):
                shutil.move(temp_file, output_path)
        
        if not os.path.exists(output_path):
            raise Exception("No se generó el archivo de salida")
            
    except subprocess.CalledProcessError as e:
        raise Exception(f"Error ejecutando {tool}: {e.stderr.decode() if e.stderr else str(e)}")

# ═══════════════════════════════════════════════════════════
# PROCESAMIENTO
# ═══════════════════════════════════════════════════════════

def download_file(url, output_path):
    """Descargar archivo desde el servidor"""
    from urllib.parse import quote
    try:
        # Codificar la URL para manejar espacios y caracteres especiales
        # Separar la base URL de la ruta del archivo
        if '://' in url:
            parts = url.split('://', 1)
            protocol = parts[0]
            rest = parts[1]
            if '/' in rest:
                server, path = rest.split('/', 1)
                # Codificar solo la ruta, no el servidor ni el protocolo
                encoded_path = quote(path, safe='/-_.')
                url = f"{protocol}://{server}/{encoded_path}"
        
        req = Request(url)
        with urlopen(req, timeout=60) as response:
            with open(output_path, 'wb') as f:
                f.write(response.read())
        return True
    except Exception as e:
        raise Exception(f"Error descargando: {e}")

def process_series(series, tool, temp_dir):
    """Procesar una serie para generar portada"""
    
    # Parsear referencia PDF
    parts = series['cover_image'].split(':')
    if len(parts) < 3:
        return False, "Referencia inválida"
    
    volume_id = parts[1]
    page_number = int(parts[2]) if len(parts) > 2 else 1
    
    pdf_temp_path = None
    
    try:
        # Obtener volumen
        volume = http_get(f"{SERVER_URL}/api/volumes/{volume_id}")
        
        if not volume or not volume.get('file_path'):
            return False, "Volumen sin archivo"
        
        # Construir URL para descargar el PDF desde el servidor
        pdf_path = volume['file_path']
        
        # Limpiar la ruta para crear URL válida
        if pdf_path.startswith('/'):
            pdf_path = pdf_path[1:]
        
        pdf_url = f"{SERVER_URL}/{pdf_path}"
        
        # Descargar PDF temporalmente a la PC
        pdf_temp_path = os.path.join(temp_dir, f"temp-{volume_id}.pdf")
        print(f"    ⬇️  Descargando PDF...", end=' ', flush=True)
        download_file(pdf_url, pdf_temp_path)
        print(f"{Colors.GREEN}✓{Colors.RESET}")
        
        if not os.path.exists(pdf_temp_path):
            return False, "No se pudo descargar el PDF"
        
        # Generar portada en la PC (usando recursos locales)
        output_path = os.path.join(temp_dir, f"cover-{series['id']}.jpg")
        print(f"    🎨 Generando portada (página {page_number})...", end=' ', flush=True)
        convert_pdf_to_image(pdf_temp_path, output_path, page_number, tool)
        print(f"{Colors.GREEN}✓{Colors.RESET}")
        
        if not os.path.exists(output_path):
            return False, "No se generó la imagen"
        
        # Subir portada al servidor
        print(f"    ⬆️  Subiendo al servidor...", end=' ', flush=True)
        http_post_file(f"{SERVER_URL}/api/series/{series['id']}/cover", output_path)
        print(f"{Colors.GREEN}✓{Colors.RESET}")
        
        # Limpiar archivos temporales
        os.remove(output_path)
        if pdf_temp_path and os.path.exists(pdf_temp_path):
            os.remove(pdf_temp_path)
        
        return True, "OK"
        
    except Exception as e:
        # Limpiar en caso de error
        if pdf_temp_path and os.path.exists(pdf_temp_path):
            try:
                os.remove(pdf_temp_path)
            except:
                pass
        return False, str(e)

# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    """Función principal"""
    
    # Limpiar pantalla
    os.system('cls' if os.name == 'nt' else 'clear')
    
    print('═' * 60)
    log('📚', 'GENERADOR DE PORTADAS - MANGA LIBRARY', Colors.BOLD + Colors.MAGENTA)
    print('═' * 60)
    print()
    
    # Crear directorio temporal
    temp_dir = tempfile.mkdtemp(prefix='manga-covers-')
    
    try:
        # Detectar herramienta
        log('🔍', 'Detectando herramientas del sistema...', Colors.BLUE)
        tool, tool_name = detect_pdf_tool()
        
        if not tool:
            log('❌', 'ERROR: No se encontró ninguna herramienta de conversión PDF', Colors.RED)
            print()
            log('💡', 'Instala una de estas opciones:', Colors.YELLOW)
            print('   • ImageMagick: https://imagemagick.org/script/download.php')
            print('   • MuPDF: https://mupdf.com/downloads/')
            print('   • Poppler: https://poppler.freedesktop.org/')
            print('   • Ghostscript: https://www.ghostscript.com/download/gsdnld.html')
            return 1
        
        log('✅', f'Usando: {tool_name}', Colors.GREEN)
        print()
        
        # Conectar al servidor
        log('🔍', 'Conectando al servidor...', Colors.BLUE)
        log('📡', f'URL: {SERVER_URL}', Colors.CYAN)
        
        try:
            series_list = http_get(f"{SERVER_URL}/api/series")
        except Exception as e:
            log('❌', f'No se pudo conectar al servidor: {e}', Colors.RED)
            print()
            log('💡', f'Verifica que el servidor esté corriendo en {SERVER_URL}', Colors.YELLOW)
            return 1
        
        log('✅', f'Conectado. Series encontradas: {len(series_list)}', Colors.GREEN)
        print()
        
        # Filtrar series sin portada
        pending = [s for s in series_list if s.get('cover_image', '').startswith('pdf:')]
        
        if not pending:
            log('🎉', 'Todas las series ya tienen portada física', Colors.GREEN)
            print()
            return 0
        
        log('📋', f'Series sin portada: {len(pending)}', Colors.YELLOW)
        print()
        
        # Procesar cada serie
        success = 0
        failed = 0
        
        for i, series in enumerate(pending):
            title = series.get('title') or series.get('code') or str(series['id'])
            # Truncar título si es muy largo
            if len(title) > 40:
                title = title[:37] + '...'
            
            print(f"\n  [{i+1}/{len(pending)}] {Colors.BOLD}{title}{Colors.RESET}")
            
            result, message = process_series(series, tool, temp_dir)
            
            if result:
                print(f"  {Colors.GREEN}✓ Portada generada exitosamente{Colors.RESET}")
                success += 1
            else:
                print(f"  {Colors.RED}✗ Error: {message}{Colors.RESET}")
                failed += 1
        
        # Resumen
        print()
        print('═' * 60)
        log('✨', 'PROCESO COMPLETADO', Colors.BOLD)
        print('═' * 60)
        log('✅', f'Exitosas: {success}', Colors.GREEN)
        if failed > 0:
            log('❌', f'Fallidas: {failed}', Colors.RED)
        print('═' * 60)
        print()
        
        return 0 if failed == 0 else 1
        
    except KeyboardInterrupt:
        print()
        log('⚠️', 'Proceso interrumpido por usuario', Colors.YELLOW)
        return 1
        
    except Exception as e:
        log('💥', f'ERROR: {e}', Colors.RED)
        return 1
        
    finally:
        # Limpiar directorio temporal
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except:
            pass

if __name__ == '__main__':
    exit_code = main()
    
    # Pausa antes de cerrar (solo en Windows)
    if os.name == 'nt':
        input('\nPresiona Enter para salir...')
    
    sys.exit(exit_code)
